export const minimum = `
  <div id="splide" class="splide">
    <div class="splide__track">
      <ul class="splide__list">
      	<li class="splide__slide">1</li>
      	<li class="splide__slide">2</li>
      	<li class="splide__slide">3</li>
      	<li class="splide__slide">4</li>
      	<li class="splide__slide">5</li>
      	<li class="splide__slide">6</li>
      	<li class="splide__slide">7</li>
      	<li class="splide__slide">8</li>
      	<li class="splide__slide">9</li>
      </ul>
    </div>
  </div>
`;

export const sync = minimum + `
  <div id="sub" class="splide">
    <div class="splide__track">
      <ul class="splide__list">
      	<li class="splide__slide">1</li>
      	<li class="splide__slide">2</li>
      	<li class="splide__slide">3</li>
      	<li class="splide__slide">4</li>
      	<li class="splide__slide">5</li>
      	<li class="splide__slide">6</li>
      	<li class="splide__slide">7</li>
      	<li class="splide__slide">8</li>
      	<li class="splide__slide">9</li>
      </ul>
    </div>
  </div>
`;